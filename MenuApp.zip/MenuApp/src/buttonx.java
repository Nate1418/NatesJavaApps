import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;

import javax.swing.JButton;

public class buttonx extends JButton{
	
	private Color backgroundColor;
	private Color textColor;
	
	public buttonx(String label, Color bgColor, Color txtColor) {
		super(label);
		this.backgroundColor = bgColor;
		this.textColor = txtColor;
		setOpaque(false);
		setContentAreaFilled(false);
		setFocusPainted(false);
		setBorderPainted(false);
		
	}
	
	protected void paintComponent(Graphics g) {
		
		Graphics2D g2 = (Graphics2D) g.create();
		g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		if(getModel().isPressed()) {
			g2.setColor(backgroundColor.darker());
			
		}else if(getModel().isRollover()){
			g2.setColor(backgroundColor.brighter());
		}else {
			g2.setColor(backgroundColor);
		}
		
		g2.fill(new RoundRectangle2D.Double(0,0,getWidth(),getHeight(),20,20));
		
		g2.setColor(textColor);
		g2.drawString(getText(), getWidth()/2-g2.getFontMetrics().stringWidth(getText())/2, getHeight()/2+g2.getFontMetrics().getAscent()/4);
		
		g2.dispose();
		
	}
}
