import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class div extends JFrame implements ActionListener {

	JPanel panel;
	JPanel inputp;
	buttonx Calc;
	textBox b1;
	textBox b2;
	JLabel sign;
	public div() {
		
	panel = new JPanel();
	panel.setBackground(Color.white);
	panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
	
	inputp = new JPanel();
	inputp.setLayout(new BoxLayout(inputp, BoxLayout.X_AXIS));
	
	
	Calc = new buttonx("First number",Color.red,Color.white);
	Calc.setAlignmentX(CENTER_ALIGNMENT);
	Calc.addActionListener(this);
	
	b1 = new textBox("First number ", 10);
	b2 = new textBox("Second number ", 10);
	
	sign = new JLabel("÷");
	
	inputp.add(Box.createGlue());
	inputp.add(b1);
	inputp.add(sign);
	inputp.add(b2);
	
	panel.add(inputp);
	panel.add(Box.createVerticalStrut(10));
	panel.add(Calc);
	
	
	
	this.add(panel);
	this.setSize(300,100);
	this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		try {
			Double x = Double.parseDouble(b1.getText());
			Double y = Double.parseDouble(b2.getText());
			
			double result = x /y;
			
			JOptionPane.showMessageDialog(this, "The Result is: "+ result, "Calculation Result", JOptionPane.INFORMATION_MESSAGE);
			b1.setText("");
			b2.setText("");
		}
		
		catch (NumberFormatException ex) {
			JOptionPane.showMessageDialog(this, "Invalid input please insert valid input");
			b1.setText("");
			b2.setText("");
		}
		
	}
}








































