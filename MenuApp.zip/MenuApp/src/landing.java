import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class landing extends JFrame implements  ActionListener{

	buttonx Maths;
	buttonx Jokes;
	buttonx quest;
	buttonx ex;
	
	
	
	JPanel panel;
	
	public landing() {
		
		panel = new JPanel();
		panel.setOpaque(false);
		panel.setBackground(Color.white);
		panel.setBounds(0,0,300,200);
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		
		 Maths = new buttonx("Mathematics", Color.BLUE,Color.WHITE);
		 Maths.setAlignmentX(CENTER_ALIGNMENT);
		 Maths.addActionListener(this);
		 
		 Jokes = new buttonx("Jokes", Color.blue,Color.WHITE);
		 Jokes.setAlignmentX(CENTER_ALIGNMENT);
		 Jokes.addActionListener(this);
		 quest = new buttonx("Questions", Color.blue,Color.WHITE);
		 quest.addActionListener(this);
		 quest.setAlignmentX(CENTER_ALIGNMENT);
		 ex = new buttonx("Exit", Color.red,Color.WHITE);
		 
		 ex.setAlignmentX(CENTER_ALIGNMENT);
		 
		
	
		 panel.add(Box.createGlue());
		 panel.add(Maths);
		 panel.add(Box.createRigidArea(new Dimension(0,20)));
		 panel.add(Jokes);
		 panel.add(Box.createRigidArea(new Dimension(0,20)));
	   	panel.add(quest);
	   	panel.add(Box.createRigidArea(new Dimension(0,20)));
	   	panel.add(ex);
	   	panel.add(Box.createGlue());
		

	this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
	this.setSize(300,300);
	this.add(panel);
	this.setVisible(true);
	}
	
	
	
	
	
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==Maths) {
			new mathematics();
		}
		else if(e.getSource()==Jokes) {
			new laugh();
		}
		else if (e.getSource()==quest) {
			new info();
		}
	}

}
