import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class info extends JFrame implements ActionListener {

	JPanel panel;
	JPanel inputp;
	textBox name;
	textBox surname;
	textBox age;
	textBox height;
	textBox weight;
	
	JLabel head;
	buttonx enter;
	
	
	public info() {
		panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.setBackground(Color.white);
		
		inputp = new JPanel();
		inputp.setLayout(new BoxLayout(inputp, BoxLayout.Y_AXIS));
		inputp.setSize(200,400);
		
		
		name = new textBox("Name", 10);
		surname = new textBox("Surname", 10);
		age = new textBox("Age", 10);
		height = new textBox("Height", 10);
		weight = new textBox("Weight", 10);
		
		enter = new buttonx("Enter", Color.blue,Color.WHITE);
		enter.setAlignmentX(Component.CENTER_ALIGNMENT);
		enter.addActionListener(this);
		
		head = new JLabel("Enter your Details");
		head.setFont(new Font("Serif",Font.BOLD,30));
		head.setForeground(Color.blue);
		
		
		
		panel.add(head);
		panel.add(inputp);
		inputp.add(Box.createGlue());
		inputp.add(name);
		inputp.add(Box.createRigidArea(new Dimension(0,10)));
		inputp.add(surname);
		inputp.add(Box.createRigidArea(new Dimension(0,10)));
		inputp.add(age);
		inputp.add(Box.createRigidArea(new Dimension(0,10)));
		inputp.add(height);
		inputp.add(Box.createRigidArea(new Dimension(0,10)));
		inputp.add(weight);
		
		inputp.add(Box.createVerticalStrut(20));
		panel.add(enter);
		panel.add(Box.createGlue());
		
		
		
		
		
		this.add(panel);
		this.setSize(300,500);
		this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		try {
			String name1 = name.getText();
			String surn = name.getText();
			int age1 = Integer.parseInt(age.getText());
			int heigh1 = Integer.parseInt(height.getText());
			int weigh1 = Integer.parseInt(weight.getText());
			
			
			
			
			JOptionPane.showMessageDialog(this, "Name: " + name1+ "\n" + "Surname: " + surn+ "\n" + " Age: " + age1 + " \n"+ " Height: " + heigh1 
					+ "\n" + "Weight: "+ weigh1, "Your Bio", JOptionPane.INFORMATION_MESSAGE);
		}
		catch(NumberFormatException ex) {
			JOptionPane.showMessageDialog(this, "Invalid input please insert proper input", "Error!!", JOptionPane.ERROR_MESSAGE);
			
			
		}
	}

}






















































