import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JTextField;

public class textBox extends JTextField implements FocusListener {

	private String placeholder; 
	public textBox(String place, int columns) {
		super(columns);
		this.placeholder = place;
		setText(place);
		setForeground(Color.black);
		addFocusListener(this);
		
		setPreferredSize(new Dimension(100,30));
	}
	@Override
	public void focusGained(FocusEvent e) {
		// TODO Auto-generated method stub
		if(getText().equals(placeholder)) {
			setText("");
		}
	}
	@Override
	public void focusLost(FocusEvent e) {
		// TODO Auto-generated method stub
		if(getText().isEmpty()) {
			setText(placeholder);
		}
	}
}
