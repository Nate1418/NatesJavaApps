import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class mathematics  extends JFrame implements ActionListener{

	JPanel panel;
	buttonx add;
	buttonx sub;
	buttonx mult;
	buttonx div;
	public mathematics() {
		panel = new JPanel();
		panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
		panel.setBackground(Color.white);
		
		add = new buttonx("Addition", Color.yellow, Color.white);
		add.setAlignmentX(CENTER_ALIGNMENT);
		add.addActionListener(this);
		sub = new buttonx("Subtraction", Color.green, Color.white);
		sub.setAlignmentX(CENTER_ALIGNMENT);
		sub.addActionListener(this);
		mult = new buttonx("Multiplication", Color.cyan, Color.WHITE);
		mult.setAlignmentX(CENTER_ALIGNMENT);
		mult.addActionListener(this);
		div = new buttonx("Division", Color.MAGENTA, Color.WHITE);
		div.setAlignmentX(CENTER_ALIGNMENT);
		div.addActionListener(this);
		
		
		
		panel.add(Box.createGlue());
		panel.add(add);
		panel.add(Box.createRigidArea(new Dimension(0,20)));
		panel.add(sub);
		panel.add(Box.createRigidArea(new Dimension(0,20)));
		panel.add(mult);
		panel.add(Box.createRigidArea(new Dimension(0,20)));
		panel.add(div);
		panel.add(Box.createGlue());
		
		
		
		this.add(panel);
		this.setSize(300,300);
		this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if (e.getSource()== add) {
			new add();
		}
		else if (e.getSource()== sub) {
			new sub();
		}
			
		else if (e.getSource()==mult) {
			new mult();
		}
		else if (e.getSource() == div){
			new div();
		}
		
	}
}
