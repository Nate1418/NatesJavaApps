import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class add extends JFrame implements ActionListener{
	JPanel inputp;
	JPanel panel;
	textBox box1;
	textBox box2;
	JLabel sign;
	buttonx calc;
	public add() {
	
	panel = new JPanel();
	panel.setLayout(new BoxLayout(panel,BoxLayout.Y_AXIS));
	panel.setAlignmentX(CENTER_ALIGNMENT);;
	panel.setBackground(Color.white);
	
	inputp = new JPanel();
	inputp.setLayout(new BoxLayout(inputp, BoxLayout.X_AXIS));
	
	
	
	box1 = new textBox("First Number", 10);
	box2 = new textBox("Second Number", 10);
	sign = new JLabel("+");
	calc = new buttonx("Calculate", Color.red,Color.white);
	calc.setAlignmentX(CENTER_ALIGNMENT);
	calc.addActionListener(this);
		
		
	inputp.add(Box.createGlue());
	inputp.add(box1);
	inputp.add(sign);
	inputp.add(box2);
	
	
	panel.add(inputp);
	panel.add(Box.createVerticalStrut(10));
	panel.add(calc);
	panel.setSize(100,75);
	this.isOpaque();
	this.setBackground(Color.white);
	this.setSize(300,100);	
	this.add(panel);

	
	this.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	
		try {
			double x = Double.parseDouble(box1.getText());
			double y = Double.parseDouble(box2.getText());
			double result = x + y;
			
			JOptionPane.showMessageDialog(this, "The answer is: "+ result, "Calculation Result", JOptionPane.INFORMATION_MESSAGE);
		}
		catch(NumberFormatException ex) {
			JOptionPane.showMessageDialog(this, "Invalid input please insert Valid input", "Error", JOptionPane.ERROR_MESSAGE);
		box1.setText("");
		box2.setText("");
		}
	}
}




































