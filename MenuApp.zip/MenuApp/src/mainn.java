
public class mainn {

	public static void main(String[] args) {
		new landing();
	}

}
