import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class laugh extends JFrame implements ActionListener{

	JPanel panel;
	buttonx dadj;
	buttonx yomj;
	buttonx badj;
	buttonx darkj;
	
	public laugh() {
		
		panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
		panel.setBackground(Color.WHITE);
		
		dadj = new buttonx("Dad Joke", Color.green, Color.WHITE);
		dadj.setAlignmentX(CENTER_ALIGNMENT);
		dadj.addActionListener(this);
		yomj = new buttonx("Your momma Joke", Color.pink, Color.WHITE);
		yomj.setAlignmentX(CENTER_ALIGNMENT);
		yomj.addActionListener(this);
		badj = new buttonx("Bad Joke", Color.red, Color.white);
		badj.setAlignmentX(CENTER_ALIGNMENT);
		badj.addActionListener(this);
		darkj = new buttonx("Bad Joke", Color.black, Color.white);
		darkj.setAlignmentX(CENTER_ALIGNMENT);
		darkj.addActionListener(this);
		
		panel.add(Box.createGlue());
		panel.add(dadj);
		panel.add(Box.createRigidArea(new Dimension(0,20)));
		panel.add(badj);
		panel.add(Box.createRigidArea(new Dimension(0,20)));
		panel.add(yomj);
		panel.add(Box.createRigidArea(new Dimension(0,20)));
		panel.add(darkj);
		panel.add(Box.createGlue());
		
		
		
		
		
		
		this.add(panel);
		this.setSize(300,300);
		this.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource()==dadj) {
			JOptionPane.showMessageDialog(this, "My boss said “dress for the job you want, not for the job you have. \n So I went in as Batman.");
		}
		else if (e.getSource()== badj) {
			JOptionPane.showMessageDialog(this, "Why don't oysters donate to charity? Because they're shellfish....:|");
		}
		else if (e.getSource()==yomj) {
			JOptionPane.showMessageDialog(this, "Yo mama's so short, you can see her feet on her driver's license. ;)");
		}
		
		else if (e.getSource()==darkj) {
			JOptionPane.showMessageDialog(this, "My grief counselor died. He was so good, \n I don’t even care..:}");
		}
	}

	
}



























































