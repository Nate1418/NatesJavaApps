import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Calc implements ActionListener  {
	JFrame frame;
	JTextField field;
	JPanel panel;
	JButton[] numButton = new JButton[10];
	JButton[] functionButton = new JButton[9];
	JButton addButton,multButton,divButton,subButton,decButton;
	JButton eqlButton,negButton,delButton,clrButton;
	
	Font font = new Font("Ink Free", Font.BOLD,30);
	 double num1,num2,result;
	 char operator;

	
	
	Calc(){
	 frame = new JFrame("Calculator");
	 frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE);
	 frame.setSize(420,550);
	 frame.getContentPane().setBackground(Color.white);
	 frame.setLayout(null);
		
	 field = new JTextField();
	 field.setBounds(55, 15, 300, 50);
	 field.setFont(font);
	 field.setEditable(false);
	 field.setForeground(Color.DARK_GRAY);
	 
	 addButton = new JButton("+");
	 subButton = new JButton("-");
	 multButton = new JButton("x");
	 divButton = new JButton("÷");
	 clrButton = new JButton("Clr");
	 eqlButton = new JButton("=");
	 decButton = new JButton(".");
	 negButton = new JButton("(-)");
	 delButton = new JButton("Del");
	 
	 functionButton[0] = addButton;
	 functionButton[1] = subButton;
	 functionButton[2] = multButton;
	 functionButton[3] = divButton;
	 functionButton[4] = clrButton;
	 functionButton[5] = eqlButton;
	 functionButton[6] = decButton;
	 functionButton[7] = negButton;
	 functionButton[8] = delButton;
	 
	 
	 for(int i=0;i<9;i++) {
		 functionButton[i].addActionListener(this);
		 functionButton[i].setFont(font);
		 functionButton[i].setFocusable(false);
	 }
	 
	 for(int i=0; i<10;i++) {
		 numButton[i] = new JButton(String.valueOf(i));
		 numButton[i].addActionListener(this);
		 numButton[i].setFont(font);
		 numButton[i].setFocusable(false);
	 }
	
	 delButton.setBounds(150,450,100,50);
	 clrButton.setBounds(250,450,100,50);
	 negButton.setBounds(50,450,100,50);
	 
	 
	 panel = new JPanel();
	 panel.setLayout(new GridLayout(4,4,10,10));
	 panel.setBounds(30,80,330,330);
	 panel.setBackground(Color.white);
	 
	 panel.add(numButton[1]);
	 panel.add(numButton[2]);
	 panel.add(numButton[3]);
	 panel.add(addButton);
	 panel.add(numButton[4]);
	 panel.add(numButton[5]);
	 panel.add(numButton[6]);
	 panel.add(subButton);
	 panel.add(numButton[7]);
	 panel.add(numButton[8]);
	 panel.add(numButton[9]);
	 panel.add(multButton);
	 panel.add(numButton[0]);
	 panel.add(divButton);
	 panel.add(eqlButton);
	 panel.add(decButton);
	 
	 
	 
	 frame.add(negButton);
	 frame.add(clrButton);
	 frame.add(delButton);
	 frame.add(panel);
	 frame.setResizable(false);
	 frame.add(field); 
	 frame.setVisible(true);	
}
	public static void main(String[] args) {
		new Calc();
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		for(int i=0; i<10;i++) {
			if(e.getSource()== numButton[i]) {
				field.setText(field.getText().concat(String.valueOf(i)));
			}
		}
		if(e.getSource()==decButton) {
			field.setText(field.getText().concat("."));
		}
		if (e.getSource() == addButton) {
			num1 = Double.parseDouble(field.getText());
			operator = '+';
			field.setText("");
		}
		if (e.getSource()== subButton) {
			num1 = Double.parseDouble(field.getText());
			operator = '-';
			field.setText("");
		}
		if(e.getSource()== multButton) {
			num1 = Double.parseDouble(field.getText());
			operator ='*';
			field.setText("");
		}
		if(e.getSource()==divButton) {
			num1 = Double.parseDouble(field.getText());
			operator = '/';
			field.setText("");
		}
		if(e.getSource()==eqlButton) {
			num2 = Double.parseDouble(field.getText());
			
			switch(operator) {
			case '+': result =num1 + num2;
				break;
			case '-': result = num1-num2;
				break;
			case '*': result =num1 * num2;
				break;
			case '/': result =num1 /num2;
				break;
			}
			field.setText(String.valueOf(result));
			num1= result;
		}
		
		if(e.getSource()== clrButton) {
			field.setText("");
		}
		
		if(e.getSource()==delButton) {
			String string = field.getText();
			field.setText("");
			for(int i=0;i<string.length()-1;i++) {
				field.setText(field.getText()+string.charAt(i));
			}
		}
		
		if(e.getSource()==negButton) {
			double temp = Double.parseDouble(field.getText());
			temp*= -1;
			field.setText(String.valueOf(temp));
		}
		
	}

}































