# Login and Registration Application

This is a simple login and registration application built in Java using Swing for the user interface and connected to an Azure SQL Database for user data storage. Users can register by providing their full name, username, password, and confirm their password. Existing users can log in using their username and password.

## Features

- **User Registration:**
  - Users can register by providing:
    - Full Name
    - Username
    - Password
    - Confirm Password
  - The application validates the input and stores the data in the Azure SQL Database.

- **User Login:**
  - Registered users can log in using their username and password.

- **Azure SQL Database Integration:**
  - All user information is stored securely in an Azure SQL Database.

## Prerequisites

- Java 8 or higher.
- Azure SQL Database set up with the necessary tables (see the database schema section).
- Azure JDBC driver for SQL Server (`mssql-jdbc`).
- Swing library for the user interface (included in Java).

## Database Schema

To make this application work, you need to create a table in your Azure SQL Database to store the user information. Below is the schema you need to set up.

### Create `Users` Table:

```sql
CREATE TABLE Users (
    UserId INT PRIMARY KEY IDENTITY(1,1),
    FullName NVARCHAR(100),
    UserName NVARCHAR(50) UNIQUE NOT NULL,
    Password NVARCHAR(255) NOT NULL,
    CreatedAt DATETIME DEFAULT GETDATE()
);




Setup Instructions
1. Configure Azure SQL Database
Set up your Azure SQL Database and get the connection string. Replace the database connection details in the code with your own Azure SQL Database connection string.


Example connection string:
private static final String url = "jdbc:sqlserver://<your-server-name>.database.windows.net:1433;databaseName=<your-database-name>;user=<your-username>;password=<your-password>";


2. Import Required Libraries
	Make sure you have the Azure SQL JDBC driver (mssql-jdbc) in your classpath. You can download it from the official 	Microsoft site.

3. Run the Application
	Login Screen: Users can enter their username and password to log in.
	Registration Screen: If users don't have an account, they can click on "Sign Up" to register a new account.
4. Database Operations
	The application uses the following database operations:

Registration:
	Inserts the user's full name, username, and password into the Users table.
Login:
	Verifies the username and password against the data in the Users table.

How to Use
	Launch the Application:
		Run the Java application to launch the GUI.
	Sign Up:
		Enter your full name, username, and password to create a new account.
	Sign In:
		Enter your registered username and password to log in.


Future Improvements
	Password Hashing: Implement secure password hashing to avoid storing plain-text passwords.
	Error Handling: Improve error handling and user feedback messages.
	Validation: Add stronger input validation (e.g., password strength, username format).
