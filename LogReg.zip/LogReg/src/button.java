import java.awt.Color;
import java.awt.Cursor;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;

public class button extends JButton{

	private Color buttonColor;
	private Color hoverColor;
	private boolean isHovered = false;
	private boolean isPassword = false;
	
	public  button(String text, Color color, Color hoverC) {
		super(text);
		this.buttonColor = color;
		this.hoverColor = hoverC;
		
		setBorderPainted(false);
		setContentAreaFilled(false);
		setFocusPainted(false);
		setOpaque(false);
		
		
		addMouseListener(new MouseAdapter() {
			
			public void mouseEntered(MouseEvent e) {
				isHovered = true;
				setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				repaint();
			}
			
			public void mouseExited(MouseEvent e) {
				isHovered = false;
				setCursor(Cursor.getDefaultCursor());
				repaint();
			}
		});
	}
	

	
	
	public void setPasswordField(boolean isPasswordField) {
		this.isPassword = isPasswordField;
		if(isPasswordField) {
			setEchoChar('*');
		} else {
			setEchoChar((char) 0);
		}
	}
	
	private void setEchoChar(char echoChar) {
		putClientProperty("JPasswordField.echoChar", echoChar);
	}
	
	
	protected void paintComponent(Graphics g) {
		Graphics2D g2d = (Graphics2D) g.create();
		g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		
		
		g2d.setColor(isHovered ? hoverColor : buttonColor);
		g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
		
		
		
		
		g2d.dispose();
		
		super.paintComponent(g);
	}
	
	
	
}
