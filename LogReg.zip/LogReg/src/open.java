import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class open   implements ActionListener{

	private static final String url = "jdbc:sqlserver://localhost\\SQLEXPRESS:1433;databaseName=MajorBank;integratedSecurity=true";
	
	
	public static Connection getConnection() throws SQLException{
		return DriverManager.getConnection(url);
	}
	
	
	
	
	JLabel head;
	JLabel subHead;
	JLabel lab;
	JLabel fullName;
	JLabel userName;
	JLabel password;
	JLabel cPassword;
	JLabel fName;
	JLabel uName;
	JLabel pWord;
	JLabel pcWord;
	
	
	
	textfield text;
	textfield text1;
	textfield text2;
	textfield text3;
	
	customP p1 = new customP();
	panel p = new panel();
	
	button login;
	button signUp;
	
	frame f = new frame();
	public open() {
		
		head = new JLabel();
		head.setText("Welcome to Major Bank");
		head.setFont(new Font("Serif",Font.BOLD,20));
		head.setBounds(100,120, 300, 40);
		head.setForeground(Color.white);
		
		subHead = new JLabel("Already have an account?");
		subHead.setFont(new Font("Serif",Font.BOLD,10));
		subHead.setBounds(150, 150, 300, 40);
		subHead.setForeground(Color.white);
		
		lab = new JLabel("Sign Up");
		lab.setFont(new Font("Serif",Font.BOLD, 20));
		lab.setBounds(150, 10, 100, 25);
		lab.setForeground(new Color(224,33,138));
		
		text = new textfield(17,15,20);
		text.setPlaceholder("Enter Full Name");
		text.setColumns(20);
		text.setBackground(new Color(245,235,245));
		text.setBounds(100, 100, 200, 25);
		text.setForeground(Color.black);
		
		fName= new JLabel("Full Name");
		fName.setForeground(Color.black);
		fName.setBounds(100,80,200,20);
		fName.setFont(new Font("Dailog",Font.BOLD,10));
		
		text1 = new textfield(17,15,20);
		text1.setPlaceholder("Enter Username");
		text1.setColumns(20);
		text1.setBackground(new Color(245,235,245));
		text1.setBounds(100, 150, 200, 25);
		text1.setForeground(Color.black);
		
		uName = new JLabel("Username");
		uName.setForeground(Color.black);
		uName.setBounds(100,130,200,20);
		uName.setFont(new Font("Dailog",Font.BOLD,10));
		
		
		text2 = new textfield(17,15,20);
		text2.setPlaceholder("Enter Password");
		text2.setColumns(20);
		text2.setBackground(new Color(245,235,245));
		text2.setBounds(100, 200, 200, 25);
		text2.setForeground(Color.black);
		text2.setPasswordField(true);
		
		
		pWord = new JLabel("Password");
		pWord.setForeground(Color.black);
		pWord.setBounds(100,180,200,20);
		pWord.setFont(new Font("Dailog",Font.BOLD,10));
		
		
		text3 = new textfield(17,15,20);                                        
		text3.setPlaceholder("Confirm Password");
		text3.setColumns(20);
		text3.setBackground(new Color(245,235,245));
		text3.setBounds(100, 250, 200, 25);
		text3.setForeground(Color.black);
		text3.setPasswordField(true);
	
		
		pcWord = new JLabel("Confirm Password");
		pcWord.setForeground(Color.black);
		pcWord.setBounds(100,230,200,20);
		pcWord.setFont(new Font("Dailog",Font.BOLD,10));
		
		
		signUp = new button("Sign Up", new Color(224,33,138), Color.pink);
		signUp.setForeground(Color.white);
		signUp.setBounds(100,300,100,20);
		signUp.addActionListener(this);
		
		
		login = new button("Login", Color.white,Color.pink);
		login.setForeground(new Color(224,33,138));
		login.setBounds(150,200,100,20);
		login.addActionListener(this);
		
	
		
		
		p.add(lab);
		p.add(text);
		p.add(text1);
		p.add(text2);
		p.add(text3);
		p.add(signUp);
		p.add(fName);
		p.add(uName);
		p.add(pWord);
		p.add(pcWord);
		
		
		p1.setBackground(new Color(224,33,138));
		p1.setBounds(400,0,400,400);
		p1.add(head);
		p1.add(login);
		p1.add(subHead);
	
		
		f.setLocationRelativeTo(null);
		f.add(p1);
		f.setTitle("Login Page");
		f.add(p);
		f.setSize(800,400);
	}
	
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getSource() == login) {
			new reg();
			f.dispose();
		}
		
		
		if(e.getSource()==signUp) {
			String FullName = text.getText();
			String UserName = text1.getText();
			String Password = text2.getActualPassowrd().trim();
			String CPassword = text3.getActualPassowrd().trim();
			
			
			
			
			if(FullName.isEmpty() || UserName.isEmpty() || Password.isEmpty() || CPassword.isEmpty()) {
				JOptionPane.showMessageDialog(null, "Please fill int all the required boxes","Error!!!",JOptionPane.ERROR_MESSAGE);
				return;
			}
			
			if(!Password.equals(CPassword)) {
				JOptionPane.showMessageDialog(null, "Password Does not match!!","Error!!",JOptionPane.ERROR_MESSAGE);
				text2.setText("");
				text3.setText("");
				
				Password ="";
				CPassword = "";
				return;
			}
			
			boolean isInserted = DatabaseManager.insertUser(FullName, UserName, Password, CPassword);
			if(isInserted) {
				JOptionPane.showMessageDialog(f, "User registered successfully");
				new reg();
				f.dispose();
			}
			else {
				JOptionPane.showMessageDialog(f, "User failed to register");
			}
		}
		
		
	}

}
