import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class customP extends JPanel{

	public customP() {
		this.setBackground(new Color(245,33,138));
		this.setLayout(null);
		this.setVisible(true);
	}
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g.create();
		
		g2d.setPaint(Color.white);
		g2d.drawOval(350, 0, 100, 100);
		
		g2d.setPaint(Color.white);
		g2d.drawOval(-50,200,100,100);
		
		
		int[] xPoints={250,450,550};
		int[] yPoints= {300,150,400};
		g2d.setPaint(Color.white);
		g2d.drawPolygon(xPoints,yPoints,3);
		
		
		
		g2d.dispose();
	}
}
