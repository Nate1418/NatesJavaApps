import javax.swing.JLabel;

public class Bank {
	
	JLabel label;
	frame fr = new frame();
	public Bank() {
		
		
		fr.setVisible(true);
	}
}
