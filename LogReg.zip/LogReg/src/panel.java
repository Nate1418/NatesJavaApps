import java.awt.Color;

import javax.swing.JPanel;

public class panel extends JPanel{

	
	public panel() {
		
		this.setLayout(null);
		this.setBackground(Color.white);
		this.setSize(400,400);
		this.setBounds(0,0,400,400);
		this.setVisible(true);
	}
}
