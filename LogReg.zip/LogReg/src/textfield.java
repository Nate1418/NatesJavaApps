import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import javax.swing.JTextField;

public class textfield extends JTextField {

    private int archWidth;
    private int archHeight;
    private String placeholder;
    private boolean isPassword= false;
    private String actualPassword = "";

    public textfield(int width, int height, int column) {
        super(column);
        this.archHeight = height;
        this.archWidth = width;
        setOpaque(false);
       
    }
    
    public void setPasswordField(boolean isPasswordField) {
    	this.isPassword = isPasswordField;
    	if(isPasswordField) {
    		setEchoChar('*');
    		
    	}else {
    		setEchoChar((char) 0);
    	}
    }
    
    
    private void setEchoChar(char echoChar) {
    	putClientProperty("JPasswordField.echoChar",echoChar);
    }
    

    public void setPlaceholder(String placeholder) {
        this.placeholder = placeholder;
        setFont(new Font("Dialog",Font.PLAIN,10));
        repaint(); // Repaint to ensure the placeholder is drawn
    }

    public String getPlaceholder() {
        return placeholder;
    }
    
    public String getActualPassowrd() {
    	return actualPassword;
    }
    
    public void setText(String text) {
    	super.setText(text);
    	if(isPassword) {
    		actualPassword = "";
    	}
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draw rounded background
        g2d.setColor(getBackground());
        g2d.fillRoundRect(0, 0, getWidth(), getHeight(), archWidth, archHeight);

        // Draw border
        g2d.setColor(getBackground());
        g2d.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, archWidth, archHeight);

        // Draw placeholder if text is empty and field is not focused
        if (getText().isEmpty() && !isFocusOwner() && placeholder != null) {
            g2d.setColor(Color.GRAY); // Placeholder color
            FontMetrics fm = g2d.getFontMetrics();
            int padding = 5;
            int textX = getInsets().left+ padding;
            int textY = (getHeight() - fm.getHeight()) / 2 + fm.getAscent();
            g2d.drawString(placeholder, textX, textY);
        }

        g2d.dispose();

        // Paint the actual text field
        super.paintComponent(g);
    }
    
    protected void paintBorder(Graphics g) {
      
    }
    
    public char getEchoChar() {
    	if(isPassword) {
    		Object echoChar = getClientProperty("JPassword.echoChar");
    		return echoChar instanceof Character ? (char) echoChar: 0;
    	}
    	return (char)0;
    }
    
    public void replaceSelection(String content) {
    	if(isPassword) {
    		actualPassword += content;
    		super.replaceSelection(content.replaceAll(".", "*"));
    	}
    	else {
    		super.replaceSelection(content);
    	}
    }

}
