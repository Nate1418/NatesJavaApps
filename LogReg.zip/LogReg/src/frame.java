import javax.swing.JFrame;

public class frame extends JFrame{

	public frame() {
		
		this.setLayout(null);
		this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);
		this.setSize(400,500);
		this.setResizable(false);
		this.setVisible(true);
	}
}