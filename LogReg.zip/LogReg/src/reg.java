import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JOptionPane;

public class reg implements ActionListener{

	JLabel head;
	JLabel subHead;
	JLabel lHead;
	
	JLabel user;
	JLabel pass;
	
	button signUp;
	button login;
	
	textfield username;
	textfield password;
	
	
	
	panel p;
	customP p2;
	
	frame fra = new frame();
	
	public reg() {
	
	head = new JLabel("Welcome to Major Banks");
	head.setFont(new Font("Serif",Font.BOLD,20));
	head.setBounds(100,120,300,40);
	head.setForeground(Color.white);
	
	subHead = new JLabel("Dont have an Account?");
	subHead.setFont(new Font("Serif",Font.BOLD,10));
	subHead .setForeground(Color.white);
	subHead.setBounds(150, 150, 300, 40);
	
	user = new JLabel("Username");
	user.setForeground(Color.black);
	user.setBounds(100,80,200,25);
	user.setFont(new Font("Dialog",Font.BOLD,10));
	
	
	pass = new JLabel("Password");
	pass.setForeground(Color.black);
	pass.setBounds(100,130,200,25);
	pass.setFont(new Font("Dialog",Font.BOLD,10));
	
	signUp = new button("Sign Up",Color.white,Color.pink);
	signUp.setForeground(new Color(224,33,138));
	signUp.setBounds(150, 200, 100, 20);
	signUp.addActionListener(this);
	
	
	lHead = new JLabel("Sign In");
	lHead.setFont(new Font("Serif",Font.BOLD,20));
	lHead.setBounds(150, 10, 100, 25);
	lHead.setForeground(new Color(224,33,138));
	
	
	username = new textfield(17,15,20);
	username.setPlaceholder("Enter Username");
	username.setForeground(Color.black);
	username.setBounds(100, 100, 200, 25);
	username.setBackground(new Color(245,245,245));
	username.setColumns(20);
	
	password = new textfield(17,15,20);
	password.setForeground(Color.black);
	password.setBackground(new Color(245,245,245));
	password.setColumns(20);
	password.setBounds(100,150,200,25);
	password.setPlaceholder("Enter Password");
	password.setPasswordField(true);
	
	
	login = new button("Sign In", new Color(224,33,138),Color.pink);
	login.setForeground(Color.white);
	login.setBounds(100,200,100,20);
	login.addActionListener(this);
	
	
		
	p = new panel();


	
	p2 = new customP();
	p2.setBounds(400,0,400,400);
	
	
	
	p.add(lHead);
	p.add(username);
	p.add(password);
	p.add(login);
	p.add(user);
	p.add(pass);
	
	p2.add(head);
	p2.add(subHead);
	p2.add(signUp);
	
	fra.setLocationRelativeTo(null);
	fra.add(p);
	fra.add(p2);
	fra.setDefaultCloseOperation(fra.EXIT_ON_CLOSE);
	fra.setSize(800,400);	
	fra.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == signUp) {
			new open();
			fra.dispose();
		}
		
		if(e.getSource() == login) {
			
			String userName = username.getText();
			String passwordd = password.getActualPassowrd();
			
			
			if(userName.isEmpty() || passwordd.isEmpty()) {
				JOptionPane.showMessageDialog(fra, "Please make sure you fill in both boxes!!");
				return;
			}
			
			boolean isInserted = DatabaseManager.logUser(userName, passwordd);
			
			if(isInserted) {
				JOptionPane.showMessageDialog(fra, "User successfully Logged in");
				new Bank();
				fra.dispose();
			}
			
			else {
				JOptionPane.showMessageDialog(fra, "User has failed to log in");
			}
		}
	}
}
