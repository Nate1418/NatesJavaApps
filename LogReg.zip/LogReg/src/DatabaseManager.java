import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JOptionPane;

public class DatabaseManager {

	private static final String URL = "jdbc:sqlserver://major.database.windows.net:1433;database=major";
	private static final String USER = "major";
	private static final String PASSWORD = "Bankia@77";
	private static Connection conn = null;
	
	
	//method to get connection to database 
	public static Connection getConnection() {
		try {
			if (conn == null || conn.isClosed()) {
				conn = DriverManager.getConnection(URL,USER,PASSWORD);
			}
		}
			catch(SQLException e) {
				e.printStackTrace();
			}
		return conn;
		}
	
	//method to close the database connection
	public static void closeConnection() {
		try {
			if (conn != null || !conn.isClosed()) {
				conn.close();
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static boolean insertUser(String fullName, String userName, String password,String confirmPassword) {
		String query = "INSERT INTO USERS (FullName, UserName, Password, ConfirmPassword) VALUES(?,?,?,?)";
		
		try(Connection conn = getConnection(); PreparedStatement pstm = conn.prepareStatement(query)){
			
			pstm.setString(1, fullName);
			pstm.setString(2, userName);
			pstm.setString(3, password);
			pstm.setString(4, password);
			int rowsAffected = pstm.executeUpdate();
			return rowsAffected > 0;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return false;
	}
	
	public static boolean logUser(String userName, String password) {
		String query = "SELECT Password FROM USERS WHERE UserName = ?";
		try(Connection conn = getConnection();
				PreparedStatement pstm = conn.prepareStatement(query)){
			pstm.setString(1, userName);
			
			try(ResultSet rs = pstm.executeQuery()){
				if (rs.next()) {
				String storedPassword = rs.getString("Password");
				return storedPassword.equals(password);
				}
				else {
					JOptionPane.showMessageDialog(null, "User Not Found!");
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return false;
	}
	}
